__version_info__ = ('1', '0', '1', 'dev2')
__version__ = '.'.join(__version_info__)
