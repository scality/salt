'''
Created on 22 oct. 2012

@author: Christophe Vedel <christophe.vedel@scality.com>
'''

import time
import logging

from scality import supervisor

from node import Node
from rest_connector import RestConnector

class Supervisor(supervisor.Supervisor):
    '''
    classdocs
    '''

    def __init__(self, url):
        super(Supervisor, self).__init__(url=url)
        
    def get_ring_list(self):
        return sorted(self.supervisorConfigMain().keys())

    def get_info(self, name):
        return self.supervisorConfigDso(dsoname=name)
    
    def get_ring(self, name):
        return _Ring(self, name)
    
    def assign_key_to_node(self, dsoname, ip, port, key):
        if type(key) == unicode: key = str(key)
        self.nodeAssignId(key, dsoname=dsoname, address="%s:%d" % (ip, port))
        
    def join_node(self, ip, port):
        self.supervisorConfigNode(action="join", address="%s:%d" % (ip, port), vnodeid=0, doparse=False)
        
    def leave_node(self, ip, port):
        self.supervisorConfigNode(action="leave", address="%s:%d" % (ip, port), vnodeid=0, doparse=False)

    def create_ring(self, name):
        self.ringCreate(name)
        return True
    
    def delete_ring(self, name):
        self.ringDelete(name)
        return True
    
    def list_servers(self, sfilter='.*'):      
        return self.serverList(sfilter)
    
    def add_server(self, name, address, port, ssl):
        self.serverAdd(name, address, port, not ssl)
        return True

    def remove_server(self, address, port):
        self.serverRemove(address, port)
        return True
        
    def add_node_to_ring(self, address, port, ring_name):
        return self.nodeSetRing(ring_name, address, port)

    def remove_node_from_ring(self, address, port, ring_name):
        return self.nodeRemoveRing(ring_name, address, port)

    def add_rest_connector_to_ring(self, address, port, ring_name):
        return self.connectorSetRing(ring_name, address, port)

    def remove_rest_connector_from_ring(self, address, port, ring_name):
        return self.connectorRemoveRing(ring_name, address, port)

class _Ring(object):
    '''
    Convenience API, linked to a supervisor.
    '''
    
    def __init__(self, sup, name):
        self._sup = sup
        self._name = name
        
    def get_name(self):
        return self._name
    
    def get_info(self):
        return self._sup.get_info(self._name)   
    
    def by_name(self, name):
        for n in self._nodes():
            if n['name'] == name:
                return Node.from_info(n)
        connectors = self._sup.supervisorConfigBizstore(action="view", dso_filter=self._name)
        for c in connectors['restconnectors']:
            if c['name'] == name:
                return RestConnector.from_info(c)
        return None
    
    def _nodes(self):
        return self.get_info()["nodes"]
    
    def has_node(self, ip, port):
        addr = "%s:%d" % (ip, port)
        for n in self._nodes():
            if n["addr"] == addr: 
                return True
        return False
    
    def add_node(self, ip, port):
        return self._sup.add_node_to_ring(ip, port, self._name)
    
    def remove_node(self, ip, port):
        return self._sup.remove_node_from_ring(ip, port, self._name)
        
    def assign_key_to_node(self, ip, port, key):
        self._sup.assign_key_to_node(self._name, ip, port, key)
        
    def get_assigned_key(self, ip, port):
        for node in self._nodes():
            if node["ip"] == ip and int(node["chordport"]) == port:
                key = node["key"]
                if key == 'N/A': return key
                return "%040X" % int(key, 16)
        return ""
        
    def get_states(self, ip, port):
        for node in self._nodes():
            if node["ip"] == ip and int(node["chordport"]) == port:
                return node["state"]
        return ()
        
    def _count_nodes(self, state, nodes=None):
        if not nodes: nodes = self._nodes()
        return len([n for n in nodes if state in n["state"]])
        
    def nb_running_nodes(self):
        return self._count_nodes('RUN')
    
    def nb_oos_nodes(self):
        return self._count_nodes('OUT_OF_SERVICE')
    
    def nb_new_nodes(self):
        return self._count_nodes('NEW')
    
    def join_oos_nodes(self, retry=3, wait=3):
        for unused in range(retry):
            nb_oos = 0
            for n in self._nodes():
                if ('OUT_OF_SERVICE' in n["state"]):
                    port = int(n["addr"].partition(":")[2])
                    nb_oos += 1
                    self._sup.join_node(n["ip"], port)
                    time.sleep(wait)
        
            if nb_oos > 0 :
                time.sleep(wait)
            else:
                return True
        return False
    
    def wait_for(self, expected_running_or_new, ip, port, expected_state):
        '''
        Wait for expected_running nodes to be in the RUN state and
        the node identified by (ip, port) to be in expected_state 
        '''
        logger = logging.getLogger('scalitycs')
        while True:
            nodes = self.get_info()["nodes"]
            nb_running = self._count_nodes('RUN', nodes=nodes)
            nb_new = self._count_nodes('NEW', nodes=nodes)
            running_ok = ((nb_running + nb_new) == expected_running_or_new)
            expected_ok = False
            for n in nodes:
                if  (ip in n["ip"] and port == int(n["chordport"])):
                    expected_ok = (n["state"][0] == expected_state)
            if running_ok and expected_ok: return
            logger.debug('Still waiting n_running %d nb_new %d expected %d, state %s expected %s' % (nb_running, nb_new, expected_running_or_new, n["state"][0], expected_state))
            time.sleep(3)

    def wait_for_balanced(self):
        '''
        Wait until no node is in the balance state.
        '''
        logger = logging.getLogger('scalitycs')
        while True:
            nodes = self.get_info()["nodes"]
            nb_src = self._count_nodes('BAL(SRC)', nodes=nodes)
            nb_dst = self._count_nodes('BAL(DST)', nodes=nodes)
            no_balance = ((nb_src == 0) and (nb_dst == 0))
            if no_balance: return
            logger.debug('Still waiting %d balance sources, %d balance destinations' % (nb_src, nb_dst))
            time.sleep(30)

    def _rest_connectors(self):
        return self._sup.supervisorConfigBizstore(action="view", dso_filter=self._name)['restconnectors']

    def has_rest_connector(self, ip, port):
        ident = "%s:%d" % (ip, port)
        for n in self._rest_connectors():
            if n["ident"] == ident: 
                return True
        return False
    
    def add_rest_connector(self, ip, port):
        return self._sup.add_node_to_ring(ip, port, self._name)
    
    def remove_rest_connector(self, ip, port):
        return self._sup.remove_node_from_ring(ip, port, self._name)
        
 
