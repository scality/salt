
from version import __version__

import os
_ringsh_root = os.getenv('RINGSH_ROOT', '/usr/local/scality-ringsh/ringsh')

import site
site.addsitedir(os.path.join(_ringsh_root, 'modules'))
site.addsitedir(_ringsh_root)


import scality
from supervisor import Supervisor


def get_supervisor(host=None):
    if host:
        url = 'https://%s:2443' % host
    else:
        from ringsh import getConf
        url = getConf(('supervisor', 'url'))
    return Supervisor(url)

from node import Node

def get_node(host='localhost', number=1):
    return Node.from_host(host, number)

