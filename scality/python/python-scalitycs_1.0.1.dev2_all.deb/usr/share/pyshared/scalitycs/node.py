'''
Created on 11 oct. 2013

@author: Christophe Vedel <christophe.vedel@scality.com>
'''

from scality import node

class Node(node.Node):
    '''
    classdocs
    '''

    def __init__(self, url="http://localhost:5580", chord_addr="localhost", chord_port="4244", dso=None):
        super(Node, self).__init__(url=url, chord_addr=chord_addr, chord_port=chord_port, dso=dso)
        
    @classmethod
    def from_host(cls, host='localhost', number=1):
        url = 'https://%s:%d' % (host, 6443 + number)
        chord_port = 4243 + number
        return cls(url=url, chord_addr=host, chord_port=chord_port)
    
    @classmethod
    def from_info(cls, info):
        url = 'https://%s:%s' % (info['addr'].split(':')[0], info['adminport'])
        return cls(url=url, chord_addr=info['ip'], chord_port=info['chordport'])

