'''
Created on 24 oct. 2013

@author: Christophe Vedel <christophe.vedel@scality.com>
'''


from scality import restconnector

class RestConnector(restconnector.RestConnector):
    '''
    classdocs
    '''

    def __init__(self, url="http://localhost:5580", srws_address=None):
        super(RestConnector, self).__init__(url=url, srws_address=srws_address)
        
    @classmethod
    def from_host(cls, host='localhost'):
        url = 'https://%s:%d' % (host, 4443)
        return cls(url=url)
    
    @classmethod
    def from_info(cls, info):
        url = 'https://%s:%s' % (info['ident'].split(':')[0], info['adminport'])
        srws_address = '%s:%s' % (info['addr'], info['restport'])
        return cls(url=url, srws_address=srws_address)


