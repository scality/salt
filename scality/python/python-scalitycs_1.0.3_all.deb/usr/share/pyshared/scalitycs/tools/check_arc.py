#!/usr/bin/python

import sys
import os
import re
import time
import base64
import subprocess
import pprint
sys.path.append("/usr/local/scality-ringsh/ringsh/")
sys.path.append("/usr/local/scality-ringsh/ringsh/modules")

from utils import hexdump

from scality.daemon import DaemonFactory

from storelib.storeutils import get_replica

ring = 'dlr'
sup_url = 'https://client-cv.scality.com:2443'

cinput = sys.stdin
if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
    cinput = open(sys.argv[1], "r")

supervisor = DaemonFactory.get_instance().get_daemon("supervisor", url=sup_url, login="root", passwd="admin")
res = supervisor.supervisorConfigDso(action="view", dsoname=ring)

nodesByName = {}
nodesByAddr = {}
starter = None
for n in res["nodes"]:
    try:
        node = DaemonFactory.get_instance().get_daemon("node", url="https://%s:%s" % (n["ip"], n["adminport"]), dso=ring, chord_addr=n["ip"], chord_port=n["chordport"], login="root", passwd="admin")
        nodesByName[n["name"]] = node
        node.name = n["name"]
        nodesByAddr["%s:%s" % (n["ip"], n["chordport"])] = node
        starter = node
    except Exception, e:
        print "Skipping node: " + str(e)

def is_arc_key(k):
    return k[-2] == '7'

def parse_arc_key(k):
    if not is_arc_key(k): return None
    arck = {}
    arck['cos'] = 7
    arck['id'] = int(k[-3] + k[-1], 16)
    arck['schema'] = int(k[-5:-3], 16)
    ndk = int(k[-8:-5], 16)
    arck['ndata'] = ndk & 0x8f
    arck['ncoding'] = (ndk & 0xf80) >> 6
    arck['isCoding'] = arck['id'] >= arck['ndata']
    return arck

def is_rep_key(k):
    return k[-2] in ['%d' % i for i in range(5)]

class ChunkStatus(object):
    FLAGS = {
             1: "DELETED",
             2: "ARCHIVED",
             4: "CACHED",
             8: "PLACEHOLDER",
             16: "SYNC",
             32: "SPLIT",
             64: "NEEDQUORUM"
    }

    def __init__(self, s):
        # print "Key %s on node %s" % (k, node.name)
        self.mdver = s.find("mdver").text
        # print "mdver :       %s" % version
        flags = int(s.find("mflags").text)
        if flags == 0:
            self.mflags = "NEW"
        else:
            self.mflags = '|'.join([n for t, n in self.FLAGS.iteritems() if flags & t])
        date = s.find("atime").text
        self.atime = time.ctime(int(date))
        date = s.find("mtime").text
        self.mtime = time.ctime(int(date))
        date = s.find("ctime").text
        self.ctime = time.ctime(int(date))
        self.crf = s.find("crf").text
        self.version = s.find("version").text
        # print "version :     " + version
        self.dataversion = s.find("dataversion").text
        # print "dataversion : " + version
        self.crc = s.find("crc32").text
        # print "crc32 :       %X" % (int(crc) & 0xffffffff,)
        self.size = int(s.find("size").text)
        # print "size :        " + size
        self.archid = s.find("archid").text
        # print "archid :      " + archid
        self.archversion = s.find("archversion").text
        # print "archversion : " + version
        self.usermd = s.find("usermd").text
        if self.usermd is not None:
            use_base64 = False
            try:
                use_base64 = s.find("use_base64").text
                if int(use_base64) == 1:
                    use_base64 = True
            except:
                pass
    
        if use_base64 is True:
            self.usermd = base64.b64decode(self.usermd)
            
    def __repr__(self):
        return self.mflags

    @staticmethod
    def fromET(et):
        for s in et.findall("result"):
            status = s.find("status").text
            if status == "CHUNKAPI_STATUS_OK":
                return ChunkStatus(s)
        else:
            return None

pp = pprint.PrettyPrinter(indent=4)
for l in cinput.readlines():
    if not re.search('method="PUT"', l) and not re.search('type="end"', l):
        continue
    m = re.search("input_key=\"([0-9A-F]*)\"", l)
    if not m: continue
    input_key = m.group(1)
    print input_key
    m = re.search("ring_data_key=\"([0-9A-F]*)\"", l)
    if not m: continue
    ring_data_key = m.group(1)
    print ring_data_key
    m = re.search("ring_keys=\"([0-9A-F,:]*)\"", l)
    if not m: continue
    ring_keys = sorted([k.split(':')[0] for k in m.group(1).split(',')], cmp=lambda x, y : cmp(int(x[-2:], 16), int(y[-2:], 16)))
    print ring_keys
    for k in ring_keys:
        pk = parse_arc_key(k)
        if pk:
            pp.pprint(pk)
        successor = starter.findSuccessor(k)
        if not successor.has_key('address') or not nodesByAddr.has_key(successor['address']):
            print "Key %s, successor not found" % k
        node = nodesByAddr[successor['address']]
        et = node.chunkapiStoreOp(op="stat", key=k, extra_params={"use_base64": "1"})
        cs = ChunkStatus.fromET(et)
        pp.pprint(cs)
        dumparcmd = "/usr/local/bin/dumparcmd"
        if os.path.isfile(dumparcmd) and os.access(dumparcmd, os.X_OK):
            if pk and not pk['isCoding']:
                p = subprocess.Popen([dumparcmd], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
                p.stdin.write(cs.usermd)
                p.stdin.close()
                usermd = p.stdout.read()
                print usermd
