
from version import __version__

import os
import logging

_ringsh_root = os.getenv('RINGSH_ROOT', '/usr/local/scality-ringsh/ringsh')

import site
site.addsitedir(os.path.join(_ringsh_root, 'modules'))  # @UndefinedVariable
site.addsitedir(_ringsh_root)  # @UndefinedVariable


import scality
from supervisor import Supervisor

def setup_logger(verbose):
    logger = logging.getLogger('scalitycs')
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    if verbose > 0:
        logger.setLevel(logging.INFO)
    else:
        logger.setLevel(logging.WARNING)
    logger.addHandler(handler)

def get_supervisor(host=None):
    if host:
        url = 'https://%s:2443' % host
    else:
        from ringsh import getConf
        url = getConf(('supervisor', 'url'))
    return Supervisor(url)

from node import Node

def get_node(host='localhost', number=1):
    return Node.from_host(host, number)


class LayoutVisitor(object):
    
    def visit_site(self, name):
        pass
    
    def visit_rack(self, name):
        pass
    
    def visit_server(self, name):
        pass
    
    def visit_node(self, nid, key):
        pass
    
def _walk_elements(elements, visitor):
    for component in elements:
        if component['componenttype'] == 'Site':
            visitor.visit_site(component['name'])
            _walk_elements(component['elements'], visitor)
        elif component['componenttype'] == 'Rack':
            visitor.visit_rack(component['name'])
            _walk_elements(component['elements'], visitor)
        elif component['componenttype'] == 'Server':
            visitor.visit_server(component['name'])
            for node in component['nodes']:
                visitor.visit_node(node['nid'], node['key'])
    
def visit_layout(json_layout, visitor):
    _walk_elements(json_layout["elements"], visitor)
